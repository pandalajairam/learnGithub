package com.mobile.automation.accelerators;

public enum MobileLocator {
	ByAccessibilityId, ByXPath, ByClassName, AndroidUIAutomator, ByName, ById
}