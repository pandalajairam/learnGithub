package com.web.automation.logs;

public enum CustomLogName {
	CurrentTestClassLog,CurrentGlobalLog,CurrentTestCaseLog,CurrentSiteCoreLog
}
