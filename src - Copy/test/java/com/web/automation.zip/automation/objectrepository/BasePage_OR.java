package com.web.automation.objectrepository;

public class BasePage_OR {
	

}
