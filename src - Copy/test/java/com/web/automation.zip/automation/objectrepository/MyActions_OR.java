package com.web.automation.objectrepository;

import org.openqa.selenium.By;

public class MyActions_OR {

	public static By CreateNewRequest = By.id("createNewRequest");
	public static By CreateNewRequestheader = By.xpath("//div[@id='createActivityContent']/h1");
	public static By AgreementCheckbox = By.id("divCertifyTextValue");
	public static By RequestOrganitionradioButton_Yes = By.id("IsRequestOnBehalOfOriginatorYes");

}
