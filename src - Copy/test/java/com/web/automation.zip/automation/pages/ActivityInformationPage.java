package com.web.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import com.google.common.base.Optional;
import com.web.automation.logs.ExtentLogs;
import com.web.automation.objectrepository.ActivityInformation_OR;
import com.web.automation.utilities.CommonVariables;

public class ActivityInformationPage extends BasePage {

	public EventFiringWebDriver driver;
	public Generic objGeneric;
	public ExtentLogs extentLogs = new ExtentLogs();
	Optional<Long> timeoutInSecond = Optional.of(Long.parseLong("5"));

	public ActivityInformationPage(WebDriver driver) {
		super(driver);
		if (!actionLib.GetPageTitle().contains("Prizma")) {
			throw new IllegalStateException("This is not the 'Prizma' Activity Information page.");
		}

	}

	public void ActivityInfo(int actType) throws Throwable {

		System.out.println("**********In the ActivityInfo method********");
		objGeneric = new Generic(CommonVariables.CommonDriver.get());
		String activityTypeName = objGeneric.returnActivityType(actType);
		Thread.sleep(5000);
		if (!(activityTypeName.equalsIgnoreCase("Master Service Agreement"))) {
			try {
				actionLib.Click(CommonVariables.CommonDriver.get().findElement(ActivityInformation_OR.btnAddVenue), 2);
				Thread.sleep(3000);
				System.out.println("Is The Add new venue page is displayed " + CommonVariables.CommonDriver.get()
						.findElement(ActivityInformation_OR.btnAddVenue).isDisplayed());
				actionLib.selectByVisibleText(ActivityInformation_OR.venueType, "Accommodation", "Venu Type");
				actionLib.type(CommonVariables.CommonDriver.get().findElement(ActivityInformation_OR.venueName),
						"Dental Club");
				actionLib.type(CommonVariables.CommonDriver.get().findElement(ActivityInformation_OR.address),
						"99900 Latouche St Suite 210, Anchorage, AK");
				actionLib.type(CommonVariables.CommonDriver.get().findElement(ActivityInformation_OR.meetingCity),
						"Copenhegan");
				actionLib.selectByVisibleText(ActivityInformation_OR.meetingCountry, "Denmark", "Meeting Country");
				actionLib.type(CommonVariables.CommonDriver.get().findElement(ActivityInformation_OR.zipCode), "12345");

				String meetingFromDate = actionLib.AddNoOfDaysInCurrentDate("yyyy MMM d", 1);
				String meetingEndDate = actionLib.AddNoOfDaysInCurrentDate("yyyy MMM d", 2);

				actionLib.Click(
						CommonVariables.CommonDriver.get().findElement(ActivityInformation_OR.meetingdatefromdateIMG),
						2);

				selectDateFromDatePicker(meetingFromDate);

				actionLib.Click(
						CommonVariables.CommonDriver.get().findElement(ActivityInformation_OR.meetingdateEnddateIMG),
						2);
				selectDateFromDatePicker(meetingEndDate);

				actionLib.Click(CommonVariables.CommonDriver.get().findElement(ActivityInformation_OR.addVenue), 2);

				Thread.sleep(3000);

				actionLib.Click(
						CommonVariables.CommonDriver.get().findElement(ActivityInformation_OR.saveAdvanceButton), 2);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("Activity information page will not be displayed for activity type " + actType);
		}

	}

	private void selectDateFromDatePicker(String formattedDate) {

		String tokens[] = formattedDate.split(" ");

		String yearOfDate = tokens[0].trim();
		String monthOfDate = tokens[1].trim();
		String dayOfDate = tokens[2].trim();

		// Selects Year
		actionLib.Click(
				CommonVariables.CommonDriver.get().findElement(By.xpath("//select[@class='ui-datepicker-year']")), 0);
		actionLib.Click(CommonVariables.CommonDriver.get()
				.findElement(By.xpath("//select[@class='ui-datepicker-year']/option[text()='" + yearOfDate + "']")), 0);

		// Selects Month
		actionLib.Click(
				CommonVariables.CommonDriver.get().findElement(By.xpath("//select[@class='ui-datepicker-month']")), 0);
		actionLib.Click(CommonVariables.CommonDriver.get().findElement(
				By.xpath("//select[@class='ui-datepicker-month']/option[text()='" + monthOfDate + "']")), 0);

		// Selects Date
		actionLib.Click(CommonVariables.CommonDriver.get()
				.findElement(By.xpath("//a[contains(@class,'ui-state-default') and text()='" + dayOfDate + "']")), 0);
	}

}
