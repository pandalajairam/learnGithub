package com.web.automation.pages;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.google.common.base.Optional;
import com.web.automation.logs.ExtentLogs;
import com.web.automation.utilities.CommonVariables;
import com.web.automation.objectrepository.GeneralActivity_OR;

public class GeneralActivityPage extends BasePage {

	public EventFiringWebDriver driver;
	public Generic objGeneric;
	public ExtentLogs extentLogs = new ExtentLogs();
	Optional<Long> timeoutInSecond = Optional.of(Long.parseLong("5"));

	public GeneralActivityPage(WebDriver driver) {
		super(driver);
		if (!actionLib.GetPageTitle().contains("Prizma")) {
			throw new IllegalStateException("This is not the 'Prizma' login page.");
		}

	}

	public void general(int actType, int someVal) throws Throwable {

		objGeneric = new Generic(CommonVariables.CommonDriver.get());

		String activityTypeName = objGeneric.returnActivityType(actType);

		try {

			System.out.println("In the general method of the GeneralActivity page");
			Thread.sleep(5000);
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.activitytitletextbox), 2);

			actionLib.type(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.activitytitletextbox),
					"HC Activity Title");

			actionLib.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.FromDate), 5);

			String startDate = actionLib.getCurrentDataTime("yyyy MMM d");
			/*
			 * actionLib.Click(CommonVariables.CommonDriver.get().findElement(
			 * By.xpath("//td[contains(@class,'datepicker-today')]/a[text()='" +
			 * startDate + "']")), 0);
			 */

			/*
			 * actionLib.Click(CommonVariables.CommonDriver.get().findElement(
			 * GeneralActivity_OR.toDate), 5);
			 */
			selectDateFromDatePicker(startDate);
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.toDate), 5);
			String toDate = actionLib.AddNoOfDaysInCurrentDate("yyyy MMM d", 4);
			selectDateFromDatePicker(toDate);
			/*
			 * String EndDate = actionLib.AddNoOfDaysInCurrentDate("dd", 3);
			 * System.out.println("The end date is " + EndDate);
			 * actionLib.Click(CommonVariables.CommonDriver.get()
			 * .findElement(By.xpath(
			 * "//div[@id='ui-datepicker-div']//table//td/a[text()='" + EndDate
			 * + "']")), 0);
			 */

			actionLib.type(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.activitycity), "Paris");

			actionLib.selectByVisibleText(GeneralActivity_OR.drpActivityCategory, activityTypeName, "Activity type");
			Thread.sleep(3000);

			actionLib.selectByIndex(GeneralActivity_OR.drpActivitySubCategory, 1, "Activity sub type");

			actionLib.Click(
					CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.activityrelatedradiobutton));

			if (!(activityTypeName.equalsIgnoreCase("Master Service Agreement"))) {
				actionLib.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.NoAOP));

				Thread.sleep(5000);
				System.out.println("The Business text field is "
						+ CommonVariables.CommonDriver.get().findElement(By.id("BusinessNeed")).isDisplayed());
				actionLib.Click(CommonVariables.CommonDriver.get()
						.findElement(By.cssSelector("div[id='BusinessNeed'] textarea")), 2);
				actionLib.type(
						CommonVariables.CommonDriver.get()
								.findElement(By.cssSelector("div[id='BusinessNeed'] textarea")),
						"To increase the sales of the instruments");

				actionLib.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.MainObjectives), 2);

				actionLib.type(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.MainObjectives),
						"To conduct quarterly meeting");

				actionLib.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.CriteriaRationale),
						2);

				actionLib.type(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.CriteriaRationale),
						"Minimum 3 years experience");

				actionLib.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.ScopeofService), 2);
				actionLib.type(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.ScopeofService),
						"Dental surgery");

				actionLib.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.durationService), 2);
				actionLib.type(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.durationService),
						"Automation Duration");

				actionLib.Click(
						CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.advisorsORconsultants));

				actionLib.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.activityDescription),
						2);
				actionLib.type(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.activityDescription),
						"Test Activity Description");
				actionLib.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.ActivityMaterial), 2);
				actionLib.type(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.ActivityMaterial),
						"Test Description for Activity Material");

				actionLib.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.mdeonV1), 2);

				actionLib.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.externalApprovals),
						2);

				actionLib.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.researchDevelopment),
						2);

			}

			actionLib.selectByVisibleText(GeneralActivity_OR.Curency, "USD - UNITED States dollar", "Currency");
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.RequestActualAmount), 2);
			actionLib.type(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.RequestActualAmount),
					"1100");

			actionLib
					.Click(CommonVariables.CommonDriver.get().findElement(GeneralActivity_OR.btnBNAGeneralsaveAndNext));

			System.out.println("******Completed General Activity tab*******");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void selectDateFromDatePicker(String formattedDate) {

		String tokens[] = formattedDate.split(" ");

		String yearOfDate = tokens[0].trim();
		String monthOfDate = tokens[1].trim();
		String dayOfDate = tokens[2].trim();

		// Selects Year
		actionLib.Click(
				CommonVariables.CommonDriver.get().findElement(By.xpath("//select[@class='ui-datepicker-year']")), 0);
		actionLib.Click(CommonVariables.CommonDriver.get()
				.findElement(By.xpath("//select[@class='ui-datepicker-year']/option[text()='" + yearOfDate + "']")), 0);

		// Selects Month
		actionLib.Click(
				CommonVariables.CommonDriver.get().findElement(By.xpath("//select[@class='ui-datepicker-month']")), 0);
		actionLib.Click(CommonVariables.CommonDriver.get().findElement(
				By.xpath("//select[@class='ui-datepicker-month']/option[text()='" + monthOfDate + "']")), 0);

		// Selects Date
		actionLib.Click(CommonVariables.CommonDriver.get()
				.findElement(By.xpath("//a[contains(@class,'ui-state-default') and text()='" + dayOfDate + "']")), 0);
	}
}
