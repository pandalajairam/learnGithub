package com.web.automation.pages;

import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.google.common.base.Optional;
import com.web.automation.logs.ExtentLogs;
import com.web.automation.objectrepository.ActivityCategory_OR;
import com.web.automation.objectrepository.GeneralActivity_OR;
import com.web.automation.utilities.CommonVariables;

public class Generic extends BasePage {

	public EventFiringWebDriver driver;
	public ExtentLogs extentLogs = new ExtentLogs();
	Optional<Long> timeoutInSecond = Optional.of(Long.parseLong("5"));

	public Generic(WebDriver driver) {
		super(driver);
		if (!actionLib.GetPageTitle().contains("Prizma")) {
			throw new IllegalStateException("This is not the 'Prizma' login page.");
		}

	}

	public String returnActivityType(int actType) throws Throwable {
		String activityType = null;
		try {

			System.out.println("In the returnActivityType method of the Generic page");

			switch (actType) {

			case 1:
				activityType = "Advisory Boards and Committees";
				break;
			case 2:
				activityType = "Company Sponsored Research (Non-IIS)";
				break;
			case 3:
				activityType = "Contractual Arrangements";
				break;
			case 4:
				activityType = "Educational Related Activities";
				break;
			case 5:
				activityType = "Master Service Agreement";
				break;
			case 6:
				activityType = "Professional Advertising & Promotion";
				break;
			case 7:
				activityType = "Promotional Events/Activities";
				break;
			case 8:
				activityType = "Royalties";
				break;
			case 9:
				activityType = "Sponsorship of Attendance";
				break;
			case 10:
				activityType = "Training Related Activities";
				break;

			case 11:
				System.out.println("Invalid activity type");
				activityType = "Invalid activity type";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return activityType;
	}
}
