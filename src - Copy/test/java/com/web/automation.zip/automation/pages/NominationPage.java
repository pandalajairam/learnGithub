package com.web.automation.pages;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.google.common.base.Optional;
import com.web.automation.fileutils.ExcelReader;
import com.web.automation.logs.ExtentLogs;
import com.web.automation.objectrepository.ActivityCategory_OR;
import com.web.automation.objectrepository.ActivityInformation_OR;
import com.web.automation.objectrepository.GeneralActivity_OR;
import com.web.automation.objectrepository.NominationPage_OR;
import com.web.automation.utilities.CommonVariables;

public class NominationPage extends BasePage {

	public EventFiringWebDriver driver;

	public ExtentLogs extentLogs = new ExtentLogs();
	Optional<Long> timeoutInSecond = Optional.of(Long.parseLong("5"));
	private static List<Map<String, String>> listOfRecords = ExcelReader
			.readExcelDataAsMap(System.getProperty("user.dir") + "\\testdata\\Nominees_List.xlsx");

	public NominationPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public void nominationsPage() throws Throwable {

		System.out.println("******In the nominationPage method********");

		/*
		 * List<Map<String, String>> listOfRecords = ExcelReader
		 * .readExcelDataAsMap(System.getProperty("user.dir") +
		 * "\\testdata\\Nominees_List.xlsx");
		 */
		/* for (Map<String, String> rowData : listOfRecords) { */
		System.out.println("The size of the list before the for loop is " + listOfRecords.size());
		for (int i = 0; i < 5 && listOfRecords.size() != 0; i++) {

			Map<String, String> rowData = listOfRecords.get(0);
			// Delete this reord from list . so that it will not b e duplicated
			// for next activity
			listOfRecords.remove(0);

			String nominationName = rowData.get("Name");
			String email = rowData.get("Email");
			String country = rowData.get("Country");
			String type = rowData.get("Type");

			System.out.println("Nomination process started for the name: " + nominationName + ", e-mail: " + email
					+ ", Country: " + country + ", Type: " + type);
			Thread.sleep(5000);

			actionLib.Click(CommonVariables.CommonDriver.get().findElement(NominationPage_OR.nomination_Name), 2);
			actionLib.type(CommonVariables.CommonDriver.get().findElement(NominationPage_OR.nomination_Name),
					nominationName);
			actionLib.selectByVisibleText(NominationPage_OR.nomination_advanced_drpCountry, country,
					"Country dropdown");
			actionLib.selectByVisibleText(NominationPage_OR.nomination_advanced_drpType, type, "Type dropdown");
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(NominationPage_OR.nomination_btnSearch), 2);

			Thread.sleep(10000);
			actionLib.Click(CommonVariables.CommonDriver.get()
					.findElement(NominationPage_OR.nomination_nominees_section_button), 2);
			Thread.sleep(30000);
			actionLib.Click(CommonVariables.CommonDriver.get()
					.findElement(NominationPage_OR.IsGovernmentOfficialUnderLocalLawYES), 2);
			actionLib.Click(
					CommonVariables.CommonDriver.get().findElement(NominationPage_OR.IsContractNegotiationOrPartYES),
					2);
			actionLib.Click(CommonVariables.CommonDriver.get()
					.findElement(NominationPage_OR.IsRequiredToPayAPersentageOfExpensesNO), 2);
			actionLib.type(CommonVariables.CommonDriver.get().findElement(NominationPage_OR.txtHCPEmailId), email);

			if (country.equalsIgnoreCase("France")) {
				actionLib.type(CommonVariables.CommonDriver.get().findElement(By.cssSelector("[id='RPPSNumber']")),
						"12345");
			}
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(NominationPage_OR.imgDatePicker), 2);
			String startDate = actionLib.getCurrentDataTime("dd");
			By currentDate = By.xpath("//div[@id='ui-datepicker-div']//table//td/a[text()='" + startDate + "']");
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(currentDate), 2);
			actionLib.type(
					CommonVariables.CommonDriver.get().findElement(NominationPage_OR.txtnominationScopeOfService),
					"Sample test text");
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(NominationPage_OR.btnSaveNomineeDetails), 2);
			Thread.sleep(15000);
			System.out.println("Nomination process completed for the name: " + nominationName + ", e-mail: " + email);
		}
		System.out.println("The size of the list after the for loop is " + listOfRecords.size());
		System.out.println("******Completed adding nominees for all the items in the excel********");
		actionLib.Click(
				CommonVariables.CommonDriver.get().findElement(NominationPage_OR.btnSaveAndAdvanceToNextSection), 2);
		System.out.println("******Completed the nomination page********");
	}

}
