package com.web.automation.scripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.web.automation.logs.ExtentLogs;
import com.web.automation.accelerators.TestEngineWeb;
import com.web.automation.pages.ActivityCategoryPage;
import com.web.automation.pages.ActivityInformationPage;
import com.web.automation.pages.CreateRequestPage;
import com.web.automation.pages.FairMarketValuePage;
import com.web.automation.pages.GeneralActivityPage;
import com.web.automation.pages.Generic;
import com.web.automation.pages.GoToHomePage;
import com.web.automation.pages.LoginPage;
import com.web.automation.pages.NominationPage;
import com.web.automation.utilities.CommonVariables;

public class PrizmaValidation extends TestEngineWeb {

	private LoginPage loginPg;
	private CreateRequestPage requestPg;
	private GeneralActivityPage generalActPg;
	private ActivityCategoryPage activityCategoryPg;
	private GoToHomePage objGoToHomePage;
	private ActivityInformationPage objActivityInformationPage;
	private NominationPage objNavigationPage;
	private FairMarketValuePage objFairMarketValuePage;
	private String testCaseFailureReason = "";
	private boolean testCaseStatus = true;
	private String firstName = "";
	private ExtentLogs extenLogs = new ExtentLogs();

	/**
	 * @author ashish jain
	 * @param status
	 * @param reason
	 */
	public void TestCaseStatus(Boolean status, String reason) {
		if (status == false) {
			Assert.fail("Test Case Failed because - " + reason);
		}
	}

	/**
	 * @author ashish jain
	 * @throws Throwable
	 * @test case id: TCM-01
	 */
	@Test(description = "Prizma", groups = { "smoke", "regression" })
	public void Prizma_Request() throws Throwable {
		try {

			loginPg = new LoginPage(CommonVariables.CommonDriver.get());
			requestPg = loginPg.login();
			for (int actTypeNo = 6; actTypeNo <= 10; actTypeNo++) {

				if (actTypeNo != 7) {
					activityCategoryPg = new ActivityCategoryPage(CommonVariables.CommonDriver.get());
					objActivityInformationPage = new ActivityInformationPage(CommonVariables.CommonDriver.get());
					requestPg.clickCreateRequestBtn();
					generalActPg = requestPg.createRequest(actTypeNo);
					Thread.sleep(3000);
					generalActPg.general(actTypeNo, 10);
					Thread.sleep(3000);
					activityCategoryPg.ActivityType(actTypeNo);
					Thread.sleep(3000);
					objActivityInformationPage.ActivityInfo(actTypeNo);
					Thread.sleep(5000);
					objNavigationPage = new NominationPage(CommonVariables.CommonDriver.get());
					objNavigationPage.nominationsPage();
					Thread.sleep(5000);
					objFairMarketValuePage = new FairMarketValuePage(CommonVariables.CommonDriver.get());
					objFairMarketValuePage.FairMarketValue();
					Thread.sleep(5000);
					objGoToHomePage = new GoToHomePage(CommonVariables.CommonDriver.get());
					objGoToHomePage.goToHomePage();
					Thread.sleep(5000);
				} else {
					System.out.println("Not required to create an acitivity ID for Master Service Agreement ");
				}
			}
		} catch (Exception e) {
			testCaseFailureReason = "Failed to create ACS Account.";
			String stackTrace = extenLogs.getStackTraceAsString("Test01", testCaseFailureReason, e);
			extenLogs.fail("Prizma:: TCM01", testCaseFailureReason + "Failed Reason : " + stackTrace);
			testCaseStatus = false;
		}

		TestCaseStatus(testCaseStatus, testCaseFailureReason);
	}
}